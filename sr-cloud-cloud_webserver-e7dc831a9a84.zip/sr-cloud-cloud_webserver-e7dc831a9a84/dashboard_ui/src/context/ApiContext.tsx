import React, { createContext, useState, useMemo, ReactNode } from 'react';

interface ApiData {
  showApiStatus: boolean;
  message: string;
  backgroundColor: string;
}

interface ApiContextType {
  apiData: ApiData;
  setApiData: (data: ApiData) => void;
}

const defaultApiData: ApiData = {
  showApiStatus: false,
  message: '',
  backgroundColor: ''
};

const ApiContext = createContext<ApiContextType>({
  apiData: defaultApiData,
  setApiData: () => {}
});

interface ApiProviderProps {
  children: ReactNode;
}

function ApiProvider({ children }: ApiProviderProps) {
  const [apiData, setApiData] = useState<ApiData>(defaultApiData);

  const value = useMemo(() => {
    return {
      apiData,
      setApiData
    };
  }, [apiData]);

  return (
    <ApiContext.Provider value={value}>
      {children}
    </ApiContext.Provider>
  );
}

export { ApiContext, ApiProvider };
