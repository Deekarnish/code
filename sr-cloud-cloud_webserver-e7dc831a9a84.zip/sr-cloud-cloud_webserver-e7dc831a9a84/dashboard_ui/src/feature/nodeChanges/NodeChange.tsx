import React, { useContext, useEffect, useState } from "react";
import {
  Backdrop,
  Grid,
  Paper,
  FormLabel,
  TextField,
  styled,
  Typography,
} from "@mui/material";
import ActionButton from "../../components/ActionButton";
import { createRequest } from "../../services/ApiServices";
import { AddNodeData } from "../../types";
import { ApiContext } from "../../context/ApiContext";

interface NodeChangeProps {
  isEdit: boolean;
  id?: number;
  open: boolean;
  updateNodeList: () => void;
  onCancel: () => void;
}

const NodeChangeContainer = styled(Paper)`
  width: auto;
  height: auto;
  border-radius: 15px;
  padding: 8px 20px 20px 20px;
`;
const Heading = styled(Typography)`
  margin-bottom: 8px;
`;
const Label = styled(FormLabel)`
  font-weight: 700;
  font-size: 19px;
  color: #000000;
  width: 40%;
  text-align: left;
`;
const Input = styled(TextField)`
  width: 60%;
  height: 30px;
  & .MuiInputBase-root {
    height: 30px;
    background-color: #efeff0;
    font-weight: 700;
    font-size: 19px;
    color: #9fa2b4;
    border: 1px solid #000000;
    border-radius: 0;
    & input {
      padding: 4px 5px;
      text-align: center;
      height: 22px;
    }
  }
`;

function NodeChange({ isEdit, id, open, updateNodeList, onCancel }: NodeChangeProps) {
  const { setApiData } = useContext(ApiContext);

  const [nodeToAdd, setNodeToAdd] = useState<AddNodeData>({
    nodeIdentifier: "",
    serialNumber: "",
    macAddress: "",
    ipAddress: "",
    templateId: null,
    locationId: null,
    comment: "",
  });

  useEffect(() => {
    if (isEdit && id) getNodeDetails();
  }, [isEdit, id]);

  const getNodeDetails = () => {
    createRequest({
      api: "node",
      method: "fetch_by_id",
      id: id?.toString(),
    })
      ?.then(async (res) => {
        setNodeToAdd(res.data);
      })
      ?.catch((err) => {});
  };

  const onInputChange = (
    name: keyof AddNodeData,
    value: string,
    type?: string
  ) => {
    setNodeToAdd({
      ...nodeToAdd,
      [name]: type === "number" ? parseInt(value) : value,
    });
  };

  const createNode = (event: { preventDefault: () => void }) => {
    event.preventDefault();
    createRequest({
      api: "node",
      method: "create",
      body: nodeToAdd,
    })
      ?.then(async (res) => {
        setApiData({
          showApiStatus: true,
          message: "Succesffully Saved",
          backgroundColor: "#37B2E4",
        });
        updateNodeList();
      })
      ?.catch((err) => {
        setApiData({
          showApiStatus: true,
          message: "Could not save data",
          backgroundColor: "#A84849",
        });
      });
  };

  const updateNode = (event: { preventDefault: () => void }) => {
    event.preventDefault();
    createRequest({
      api: "node",
      method: "update",
      id: id?.toString(),
      body: nodeToAdd,
    })
      ?.then(async (res) => {
        setApiData({
          showApiStatus: true,
          message: "Succesffully Updated",
          backgroundColor: "#37B2E4",
        });
        updateNodeList();
      })
      ?.catch((err) => {
        setApiData({
          showApiStatus: true,
          message: "Could not update data",
          backgroundColor: "#A84849",
        });
      });
  };

  return (
    <Backdrop
      sx={{ color: "#fff", zIndex: (theme) => theme.zIndex.drawer + 1 }}
      open={open}
    >
      <Grid container justifyContent="center">
        <Grid item xs={7}>
          <NodeChangeContainer>
            <Heading variant="h6" color="secondary">
              {isEdit ? "EDIT" : "ADD"} NODE
            </Heading>
            <form
              style={{
                backgroundColor: "#FFF",
                padding: "40px 40px 16px 40px",
                borderRadius: "16px",
              }}
              onSubmit={isEdit ? updateNode : createNode}
            >
              <div className="formInputWrapper">
                <Label>Node Id</Label>
                <Input
                  placeholder="Fill in details"
                  value={nodeToAdd.nodeIdentifier}
                  onChange={(e) => onInputChange("nodeIdentifier", e.target.value)}
                  required
                />
              </div>
              <div className="formInputWrapper">
                <Label>Robert Serial Number</Label>
                <Input
                  placeholder="Fill in details"
                  value={nodeToAdd.serialNumber}
                  onChange={(e) => onInputChange("serialNumber", e.target.value)}
                />
              </div>
              <div className="formInputWrapper">
                <Label>MAC ID</Label>
                <Input
                  placeholder="Fill in details"
                  value={nodeToAdd.macAddress}
                  onChange={(e) => onInputChange("macAddress", e.target.value)}
                />
              </div>
              <div className="formInputWrapper">
                <Label>IP Address</Label>
                <Input
                  placeholder="Fill in details"
                  value={nodeToAdd.ipAddress}
                  onChange={(e) => onInputChange("ipAddress", e.target.value)}
                  required
                />
              </div>
              <div className="formInputWrapper">
                <Label>Template Plate ID</Label>
                <Input
                  placeholder="Fill in details"
                  type="number"
                  value={nodeToAdd.templateId}
                  onChange={(e) =>
                    onInputChange("templateId", e.target.value, "number")
                  }
                />
              </div>
              {/* <div className="formInputWrapper">
                <Label>Access Key</Label>
                <Input
                  placeholder="Fill in details"
                  value={nodeToAdd.serialNumber}
                  onChange={(e) =>
                    onInputChange("serialNumber", e.target.value)
                  }
                  required
                />
              </div> */}
              <div className="formInputWrapper">
                <Label>Location</Label>
                <Input
                  placeholder="Fill in details"
                  type="number"
                  value={nodeToAdd.locationId}
                  onChange={(e) =>
                    onInputChange("locationId", e.target.value, "number")
                  }
                />
              </div>
              <div className="formInputWrapper">
                <Label>Comment(s)</Label>
                <Input
                  placeholder="Fill in details"
                  value={nodeToAdd.comment}
                  onChange={(e) => onInputChange("comment", e.target.value)}
                />
              </div>
              <ActionButton
                text={isEdit ? "UPDATE" : "ADD"}
                type={"submit"}
                width={96}
                height={60}
                radius={15}
                fontSize={19}
                fontWeight={800}
                color={"#70CCF2"}
              />
              <ActionButton
                text={"Cancel"}
                width={96}
                height={60}
                radius={15}
                fontSize={19}
                fontWeight={800}
                color={"#E86B6C"}
                action={onCancel}
              />
            </form>
          </NodeChangeContainer>
        </Grid>
      </Grid>
    </Backdrop>
  );
}

export default NodeChange;
