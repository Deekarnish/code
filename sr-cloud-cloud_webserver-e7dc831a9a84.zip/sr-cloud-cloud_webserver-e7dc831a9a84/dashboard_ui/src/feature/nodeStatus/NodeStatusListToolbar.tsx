import React, { useState } from "react";
import styled from "@emotion/styled";
import { Typography, Toolbar, ListItemIcon } from "@mui/material";
import NodeCardView from "../../assets/icons/NodeCardView";
import NodeListView from "../../assets/icons/NodeListView";
import { Views } from "../../types";
import SearchBar from "../../components/SearchBar";
import ActionButton from "../../components/ActionButton";

interface NodeStatusListToolbarProps {
  action: (view: Views) => void;
}

const NodeListHeader = styled(Typography)`
  text-align: left;
  color: #252733;
`;
function NodeStatusListToolbar({ action,handleSearchChange,searchTerm,handleFilterData }:any) {
  const [selectedView, setSelectedView] = useState(Views.list);

  const setView = (view: Views) => {
    setSelectedView(view);
    action(view);
  }
  return (
    <Toolbar
      sx={{
        pl: { sm: 2 },
        pr: { xs: 1, sm: 1 },
      }}
    >
      <NodeListHeader sx={{ flex: "1 1 100%" }} variant="h6" id="tableTitle">
        All Nodes
      </NodeListHeader>
      <SearchBar searchTerm={searchTerm} handleSearchChange={handleSearchChange}/>
      <ActionButton text={"Sync"} width={76} height={24} handleFilterData={handleFilterData}/>
      <ListItemIcon sx={{cursor: 'pointer',marginLeft:"1rem",marginTop:"0.5rem"}} onClick={() => setView(Views.card)}>
        <NodeCardView sx={{ color: "#000"}} opacity={selectedView === Views.card ? 1 : 0.4} />
      </ListItemIcon>
      <ListItemIcon sx={{cursor: 'pointer',marginTop:"0.5rem"}} onClick={() => setView(Views.list)}>
        <NodeListView sx={{ color: "#000", paddingTop: "5px" }} opacity={selectedView === Views.list ? 1 : 0.4} />
      </ListItemIcon>
    </Toolbar>
  );
}

export default NodeStatusListToolbar;
