import axios from 'axios';
import Urls from './Urls';

const ApiClient = {
    get client() {
        const token = sessionStorage.getItem('token') || null;
        const headers: any = {
            'Cache-Control': 'no-cache',
            client_code: 'hsds_front',     
        };
        if(token) {
            headers.Authorization = 'Bearer ' + token;
        }
        return axios.create({
            baseURL:  Urls.BaseUrl,
            timeout: 18000,
            headers: headers,
        });
    },
};

export default ApiClient;
