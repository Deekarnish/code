import ApiClient from './ApiClient';
import Urls from './Urls';
import { handleQuery } from '../utils';

export type api = {
    method: 'create' | 'fetch_by_id' | 'fetch_all' | 'delete' | 'update' | 'patch' | 'node_action'|'put';
    api: keyof typeof Urls;
    id?: string;
    body?: any;
    params?: any;
};

export const createRequest = (req: api) => {
    if (req.method === 'create') return ApiClient.client.post(Urls[req.api], req.body);
    else if (req.method === 'fetch_by_id') return ApiClient.client.get(Urls[req.api] + '/' + req.id);
    else if (req.method === 'fetch_all') {
        const params = handleQuery(req?.params || {});
        return ApiClient.client.get(Urls[req.api] + (params ? `?${params}` : ''));
    } else if (req.method === 'delete') {
        const params = handleQuery(req?.params || {});
        if(req?.params){
            return ApiClient.client.delete(Urls[req.api] +  (params ? `?${params}` : ''))
        }else{
            return ApiClient.client.delete(Urls[req.api] + '/' + req.id);
        }
        
    }
    else if (req.method === 'update') return ApiClient.client.post(Urls[req.api] + '/' + req.id, req.body);
    else if (req.method === 'patch') {
        const params = handleQuery(req?.params || {});
        return ApiClient.client.patch(Urls[req.api] + '/' + req.id + (params ? `?${params}` : ''));
    }else if (req.method === 'put'){
        const params = handleQuery(req?.params || {});
        return ApiClient.client.put(Urls[req.api]   + (params ? `?${params}` : ''), req.body);
    }
    else if (req.method === 'node_action') {
        const params = handleQuery(req?.params || {});
        return ApiClient.client.post('/node/' + req.id + Urls[req.api] + (params ? `?${params}` : '') , {});
    }
};
