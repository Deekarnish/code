import React, { useEffect, useState } from 'react'
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import ListItemText from '@mui/material/ListItemText';
import Select, { SelectChangeEvent } from '@mui/material/Select';
import { createRequest } from '../../services/ApiServices';
import jsPDF from 'jspdf';
import { CSVLink, CSVDownload } from "react-csv";

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
    PaperProps: {
        style: {
            maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
            width: 250,
            backgroundColor: 'white',
            color: 'black'
        },
    },
};



export default function Measurement() {

    const [nodeValue, setNodeValue] = useState<any>([]);
    const [nodeId, setNodeId] = useState<any>([])
    const [measurementData, setMeasurementData] = useState<any>()
    const [measurementReport, setMeasurementReport] = useState<any>()
    const [startDate, setStartDate] = useState(new Date(new Date().setDate(new Date().getDate() - 30)))
    const [endDate, setEndDate] = useState(new Date())

    const firstThreeAvailabilityDetails = measurementReport?.availabilityDetails || [];
    const firstThreeThroughputReport = measurementReport?.throughputReport || []
    const firstThreeTransactionTimeDetails = measurementReport?.transactionTimeDetails || [];

    const firstThreeObjects = [
        ...firstThreeAvailabilityDetails,
        ...firstThreeThroughputReport,
        ...firstThreeTransactionTimeDetails
    ];

    const handleChange = (event: SelectChangeEvent<typeof nodeValue>) => {
        const { value } = event.target;
        setNodeValue(typeof value === 'string' ? value.split(',') : value as string[]);
    };

    const getNodeList = async () => {
        createRequest({
            api: "node",
            method: "fetch_all",

        })
            ?.then(async (res) => {
                let data = res.data.map((item: any) => {
                    return {
                        nodeIdentifier: item.nodeIdentifier,
                        nodeId: item.nodeId
                    }
                })
                setNodeId(data)
            })
            ?.catch((err) => {
            });

    }

    const getMeasurement = async () => {
        createRequest({
            api: 'dashboardMeasurment',
            method: "fetch_all",
            params: {
                startDate: startDate.toISOString(),
                endDate: endDate.toISOString(),
                nodeIds: nodeValue
            },
        })
            ?.then(async (res) => {
                const data = res?.data
                setMeasurementData(data)
            })
            ?.catch((err) => {
            });
    }

    const getDashBoardDetailReport = async () => {
        try {
            const res = await createRequest({
                api: 'dashboardMeasurmentReport',
                method: "fetch_all",
                params: {
                    startDate: startDate.toISOString(),
                    endDate: endDate.toISOString(),
                    nodeIds: nodeValue
                },
            });
            const data = res?.data;
            setMeasurementReport(data);
            if (data) {
                const pdf = new jsPDF();
                const jsonDataString = JSON.stringify(data, null, 4);
                const lines = pdf.splitTextToSize(jsonDataString, pdf.internal.pageSize.width - 20);
                let yPos = 10;

                lines.forEach((line: any, index: any) => {
                    if (yPos + 10 > pdf.internal.pageSize.height) {
                        pdf.addPage();
                        yPos = 10;
                    }
                    pdf.text(line, 10, yPos);
                    yPos += 10;
                });

                pdf.save("measurement_detail_report.pdf");
            }
        } catch (error) {
            console.error("Error fetching dashboard report:", error);
        }
    };

    const getDashBoardReport = () => {
        if (measurementData) {
            const pdf = new jsPDF();
            const jsonDataString = JSON.stringify(measurementData, null, 4);
            const lines = pdf.splitTextToSize(jsonDataString, pdf.internal.pageSize.width - 20);
            let yPos = 10;

            lines.forEach((line: any, index: any) => {
                if (yPos + 10 > pdf.internal.pageSize.height) {
                    pdf.addPage();
                    yPos = 10;
                }
                pdf.text(line, 10, yPos);
                yPos += 10;
            });

            pdf.save("measurement_report.pdf");
        }
    }

    useEffect(() => {
        getNodeList()
    }, [])

    return (
        <>
            <div style={{ display: "flex", gap: "10%", padding: "0 100px", flexWrap: "wrap", rowGap: "30px" }} >
                <div style={{ display: "flex", flexDirection: "column", rowGap: "20px" }}>

                    <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }}>
                        <label>Start Date</label>
                        <DatePicker
                            selected={startDate}
                            onChange={(date: any) => setStartDate(date)}
                            popperPlacement="top-start"
                            dateFormat="yyyy-dd-MM"
                            placeholderText="Start date"
                            className="cutom_datepicker"
                        />
                    </div>

                    <div style={{ display: "flex", flexDirection: "column", rowGap: "10px" }}>
                        <label>End Date</label>
                        <DatePicker
                            selected={endDate}
                            onChange={(date: any) => setEndDate(date)}
                            dateFormat="yyyy-dd-MM"
                            placeholderText="End date"
                            className="cutom_datepicker"
                            popperPlacement="top-start"
                        />
                    </div>


                    <FormControl sx={{ m: 0, width: 325 }}>
                        <InputLabel id="demo-multiple-checkbox-label" sx={{ mt: -1, p: 0 }}>Node Selector</InputLabel>
                        <Select
                            labelId="demo-multiple-checkbox-label"
                            id="demo-multiple-checkbox"
                            multiple
                            value={nodeValue}
                            onChange={handleChange}
                            input={<OutlinedInput label="Node Selectors" style={{ padding: "10px", height: "40px" }} />}
                            renderValue={(selected) => {
                                const selectedNodeIdentifiers = selected.map((value: any) => {
                                    const node = nodeId.find((n: any) => n.nodeId === value);
                                    return node ? node.nodeIdentifier : value;
                                });
                                return selectedNodeIdentifiers.join(', ');
                            }}
                            MenuProps={MenuProps}
                        >
                            {nodeId.map((node: any, index: any) => (
                                <MenuItem key={index} value={node.nodeId}>
                                    <ListItemText primary={node.nodeIdentifier} />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </div>


                <div style={{ display: "flex", gap: "60px", flexWrap: "wrap" }}>
                    <div style={{ display: "flex", flexDirection: "column", rowGap: "20px", flexWrap: "wrap" }}>
                        <div style={{ backgroundColor: "#D9D9D9", padding: "20px", fontWeight: "700", width: "100%" }}>Throughput - Mean Average Transaction Time</div>
                        <div style={{ backgroundColor: "#D9D9D9", padding: "20px", fontWeight: "700", width: "100%" }}>Throughput - Robotics Solution</div>
                        <div style={{ backgroundColor: "#D9D9D9", padding: "20px", fontWeight: "700", width: "100%" }}>Availability - Robotics Solution</div>
                    </div>

                    <div style={{ display: "flex", flexDirection: "column", rowGap: "15px" }}>
                        <div>
                            <div style={{ padding: "15px", borderRadius: "5px", outline: "none", marginTop: "5px", width: "180px", backgroundColor: "#EFEFF0", border: "0.5px solid black" }}>{measurementData ? measurementData?.totalMeanAverageTime : "PM1 value Display Here"}</div>
                        </div>

                        <div>
                            <div style={{ padding: "15px", borderRadius: "5px", outline: "none", marginTop: "10px", width: "180px", backgroundColor: "#EFEFF0", border: "0.5px solid black" }}>{measurementData ? measurementData?.totalThroughputPercentage : "PM2 value Display Here"}</div>
                        </div>

                        <div>
                            <div style={{ padding: "15px", borderRadius: "5px", outline: "none", marginTop: "15px", width: "180px", backgroundColor: "#EFEFF0", border: "0.5px solid black" }}>{measurementData ? measurementData?.totalAvailabilityPercentage : "PM3 value Display Here"}</div>
                        </div>

                        <button style={{ height: "40px", width: "100%", padding: "10px", fontSize: "16px", cursor: "pointer", backgroundColor: "#4C7EFE", outline: "none", border: "none", color: "white", borderRadius: "8px", marginTop: "30px" }} onClick={getMeasurement}>Calculate</button>
                    </div>
                </div>
            </div>

            <div style={{ padding: "0 50px", marginTop: "5%" }}>
                <h3 style={{ marginLeft: "5%" }}>Reports</h3>
                <div style={{ width: "100%", border: "1px solid #000000" }}></div>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", padding: "3% 10%" }}>
                <button style={{ width: "250px", padding: "15px", outline: "none", border: "none", backgroundColor: "#D9D9D966", fontSize: "18px", fontWeight: "700", cursor: "pointer", borderRadius: "10px" }} onClick={getDashBoardReport}>Download as PDF</button>
                <>
                    <CSVLink data={firstThreeObjects}>
                        <button style={{ width: "250px", padding: "15px", outline: "none", border: "none", backgroundColor: "#D9D9D966", fontSize: "18px", fontWeight: "700", cursor: "pointer", borderRadius: "10px" }} >Download as CSV</button>
                    </CSVLink>
                </>
            </div>


            <div style={{ padding: "0 50px", marginTop: "5%" }}>
                <h3 style={{ marginLeft: "5%" }}>Detail Reports</h3>
                <div style={{ width: "100%", border: "1px solid #000000" }}></div>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", padding: "3% 10%" }}>
                <button style={{ width: "250px", padding: "15px", outline: "none", border: "none", backgroundColor: "#D9D9D966", fontSize: "18px", fontWeight: "700", cursor: "pointer", borderRadius: "10px" }} onClick={getDashBoardDetailReport}>Download as PDF</button>
                <>
                    <CSVLink data={firstThreeObjects}>
                        <button style={{ width: "250px", padding: "15px", outline: "none", border: "none", backgroundColor: "#D9D9D966", fontSize: "18px", fontWeight: "700", cursor: "pointer", borderRadius: "10px" }}>Download as CSV</button>
                    </CSVLink>
                </>
            </div>
        </>
    )
}
