import styled from '@emotion/styled'
import { Box, Typography, Button, Paper } from '@mui/material'
import React, { useContext, useEffect, useState } from 'react'
import BoxList from './BoxList'
import UserModal from './AddUserModal/UserModal'
import { createRequest } from '../../services/ApiServices'
import { AddUserDetails } from '../../types'
import { ApiContext } from '../../context/ApiContext'

const UserManagementButton = styled(Button)`
width:100%; 
padding:8px;
background-color:#363740;
border-radius:15px;
color:#ffff;
&:hover {
    background-color: #363740;  
  }
`

const AddUser = styled(Button)`
width:25%; 
padding:8px;
background-color:#37B2E4;
border-radius:8px;
color:#ffff;
&:hover {
    background-color: #37B2E4;  
  }

`

const NoAddUser = styled(Button)`
width:25%; 
padding:8px;
background-color:#37B2E4;
border-radius:8px;
color:#ffff;
&:hover {
    background-color: #37B2E4;  
  }
cursor:not-allowed;
pointer-events: none;
  opacity: 0.7;
`


export default function SettingManagement() {
    const { setApiData } = useContext(ApiContext);

    const [handleChange, setHandleChange] = useState(false)
    const [userinfo, setUserInfo] = useState<any>([])
    const [editButton,setEditbutton] = useState(false)
    const [addUser, setAdduser] = useState<AddUserDetails>({
        username: "",
        email: "",
        password: "",
        roleId: null,
    });
    const getUserDetails = async () => {
        createRequest({
            api: "getUserDetails",
            method: "fetch_all",

        })
            ?.then(async (res) => {
                let data = res.data
                const mappedData = data.map((user: any) => ({
                    id: user.userDetailId,
                    roles: user.roles,
                    userName: user.userName,
                    email: user.email,
                    roleId:user.roleId
                }));

                setUserInfo(mappedData)
            })
            ?.catch((err) => {
            });

    }

    useEffect(() => {
        getUserDetails()
    }, [])

    const onInputChange = (
        name: keyof AddUserDetails,
        value: string,
        type?: string
    ) => {
        setAdduser({
            ...addUser,
            [name]: type === "number" ? parseInt(value) : value,
        });
    };

    const roleId = localStorage.getItem('roleId')
    
    const onHandleOpen = () => {
        if(roleId === "1"){
            setEditbutton(true)
            setHandleChange(true)
        }
       
    }
    

    const onhandleClose = () => {
        setHandleChange(false)
        setAdduser({ username: "", email: "", password: "", roleId: null })
    }

    const saveModalData = () => {
        createRequest({
            api: "getUserDetails",
            method: "create",
            body: addUser,
        })
            ?.then(async (res) => {
                setApiData({
                    showApiStatus: true,
                    message: "Succesffully Saved",
                    backgroundColor: "#37B2E4",
                });
                setHandleChange(false)
                setAdduser({ username: "", email: "", password: "", roleId: null })
                getUserDetails()
            })
            ?.catch((err) => {
                setApiData({
                    showApiStatus: true,
                    message: "Could not save data",
                    backgroundColor: "#A84849",
                });
            });
    };

    const updateUserDetails = (id:any) => {
        createRequest({
          api: "editUserDetails",
          method: "put",
          params: {
            userId: id,
          },
          body: addUser,
        })
          ?.then(async (res) => {
            setApiData({
              showApiStatus: true,
              message: "Successfully Updated",
              backgroundColor: "#37B2E4",
            });
            console.log(res,"resdatatataa");
            setHandleChange(false)
            getUserDetails()
          })
          ?.catch((err:any) => { 
            console.log(err,"error");
            
          });
      };


      const onDeleteUserDetails = (id:any) => {
        createRequest({
          api: "editUserDetails",
          method: "delete",
          params: {
            userId: id,
          },
        })
          ?.then(async (res) => {
            setApiData({
                showApiStatus: true,
                message: "Successfully Deleted",
                backgroundColor: "#37B2E4",
              });
            getUserDetails()
          })
          ?.catch((err:any) => { 
            console.log(err,"error");
            
          });
      };

return (
        <>
            <Box
                component="section" sx={{ p: 0, border: '8px solid #363740', height: "auto", width: "100%", borderRadius: "5px" }}
            >
                <section style={{ width: "100%", display: "flex", height: "100%" }}>
                    <div style={{ width: "20%", padding: "10% 2%", borderRight: "5px solid black" }}>
                        <UserManagementButton>User management</UserManagementButton>
                    </div>
                    <div style={{ width: "70%", padding: "2%" }}>
                        <div style={{ display: "flex", justifyContent: "flex-end" }}>
                            {
                                roleId !== "1" ? <NoAddUser onClick={onHandleOpen} 
                                >Add New User</NoAddUser> : <AddUser onClick={onHandleOpen} 
                                >Add New User</AddUser>
                            }
                        </div>

                        <div style={{ width: "100%", height: "auto", marginTop: "3%", backgroundColor: "#D9D9D9" }}>
                            <BoxList userinfo={userinfo} setHandleChange={setHandleChange} 
                            open={handleChange}
                             handleClose={onhandleClose} 
                             saveModalData={saveModalData} 
                             onInputChange={onInputChange} 
                             addUser={addUser}
                             updateUserDetails={updateUserDetails}
                             editButton={editButton}
                             setEditbutton={setEditbutton}
                            roleId={roleId}
                            onDeleteUserDetails={onDeleteUserDetails}
                             />
                        </div>
                    </div>
                </section>
            </Box>

            
        </>
    )
}
