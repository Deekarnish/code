import React from 'react'

export default function Verification() {
  return (
    <div>
      <h1>dsdd</h1>
    </div>
  )
}
