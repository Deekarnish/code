import {
  TableHead,
  TableRow,
  TableCell,
  TableSortLabel,
  Box,
} from "@mui/material";
import { visuallyHidden } from "@mui/utils";
import { NodeData, Order } from "../../types";

interface HeadCell {
  disablePadding: boolean;
  id: keyof NodeData;
  label: string;
  numeric: boolean;
}

const headCells: readonly HeadCell[] = [
  {
    id: "nodeId",
    numeric: false,
    disablePadding: true,
    label: "Node ID",
  },
  // {
  //   id: "currentTemplate",
  //   numeric: false,
  //   disablePadding: false,
  //   label: "Current Template",
  // },
  // {
  //   id: "templateUpdateDate",
  //   numeric: false,
  //   disablePadding: false,
  //   label: "Template Updated on",
  // },
  {
    id: "templateName",
    numeric: false,
    disablePadding: false,
    label: "templateName",
  },
  // {
  //   id: "dut1",
  //   numeric: false,
  //   disablePadding: false,
  //   label: "DUT #1",
  // },
  // {
  //   id: "dut2",
  //   numeric: false,
  //   disablePadding: false,
  //   label: "DUT #2",
  // },
  // {
  //   id: "dut3",
  //   numeric: false,
  //   disablePadding: false,
  //   label: "DUT #3",
  // },
  // {
  //   id: "dut4",
  //   numeric: false,
  //   disablePadding: false,
  //   label: "DUT #4",
  // },
  {
    id: "lastUpdatedOn",
    numeric: false,
    disablePadding: false,
    label: "Last Updated",
  },
  {
    id: "statusId",
    numeric: false,
    disablePadding: false,
    label: "Status",
  },
];

interface NodeSetupListProps {
  onRequestSort: (
    event: React.MouseEvent<unknown>,
    property: keyof NodeData
  ) => void;
  order: Order;
  orderBy: string;
  rowCount: number;
}

function NodeSetupListHead(props: NodeSetupListProps) {
  const {
    order,
    orderBy,
    rowCount,
    onRequestSort,
  } = props;
  const createSortHandler =
    (property: keyof NodeData) => (event: React.MouseEvent<unknown>) => {
      onRequestSort(event, property);
    };

  return (
    <TableHead>
      <TableRow>
        <TableCell></TableCell>
        {headCells.map((headCell) => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? "right" : "left"}
            padding={headCell.disablePadding ? "none" : "normal"}
            sortDirection={orderBy === headCell.id ? order : false}
            sx={{color:"#000"}}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={orderBy === headCell.id ? order : "asc"}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <Box component="span" sx={visuallyHidden}>
                  {order === "desc" ? "sorted descending" : "sorted ascending"}
                </Box>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
        <TableCell></TableCell>
      </TableRow>
    </TableHead>
  );
}

export default NodeSetupListHead;
