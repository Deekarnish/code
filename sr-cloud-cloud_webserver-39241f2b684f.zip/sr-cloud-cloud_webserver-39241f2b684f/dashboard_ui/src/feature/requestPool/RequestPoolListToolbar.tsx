import styled from "@emotion/styled";
import { Typography, Toolbar } from "@mui/material";

const RequestListHeader = styled(Typography)`
  text-align: left;
  color: #252733;
`;

interface RequestPoolCountProps {
  requestCount: number;
}

function RequestPoolListToolbar({ requestCount }: RequestPoolCountProps) {
  return (
    <Toolbar
      sx={{
        pl: { sm: 2 },
        pr: { xs: 1, sm: 1 },
      }}
    >
      <RequestListHeader sx={{ flex: "1 1 100%" }} variant="h6" id="tableTitle">
        All Requests{" "}
        <span
          style={{
            fontSize: "14px",
            fontWeight: 700,
            color: "#9FA2B4",
          }}
        >
          ({requestCount})
        </span>
      </RequestListHeader>
    </Toolbar>
  );
}

export default RequestPoolListToolbar;
