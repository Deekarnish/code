import React, { useContext, useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import Box from "@mui/material/Box";
import TablePagination from "@mui/material/TablePagination";
import NodeStatusListToolbar from "./NodeStatusListToolbar";
import { NodeData, Views } from "../../types";
import Paper from "@mui/material/Paper";
import ListView from "./ListView";
import CardView from "./CardView";
import { createRequest } from "../../services/ApiServices";
import { ProgressContext } from "../../context/ProgressContext";


const NodeListTable = styled(Paper)`
  background-color: #fff;
  border-radius: 8px;
  border: 1px solid #dfe0eb;
  padding: 15px 0;
  margin-top: 35px;
`;

function NodeStatusView() {
  const [page, setPage] = React.useState(0);
  const [rows, setRows] = useState<any[]>([]);
  const [filteredRows,setFilteredRows] = useState<any[]>([])
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [searchTerm,setSearchTerm] = useState('')
  const [rowsPerPageOptions, setRowsPerPageOptions] = React.useState([
    5, 10, 25,
  ]);
  const [view, setView] = React.useState(Views.list);
  const { setProgressData } = useContext(ProgressContext);

useEffect(() => {
    getNodes();
  }, []);

  const getNodes = () => {
    setProgressData({
      isLoading: true,
    });
    createRequest({
      api: "node",
      method: "fetch_all",
    })
      ?.then(async (res) => {
        setFilteredRows(res?.data)
        setRows(res?.data);
        setProgressData({
          isLoading: false,
        });
      })
      ?.catch((err) => {
        setProgressData({
          isLoading: false,
        });
      });
  };



  const changeView = (view: Views) => {
    let perPage = 5;
    let rowsPerPage = [5, 10, 25];
    if (view === Views.card) {
      perPage = 20;
      rowsPerPage = [20, 40, 60];
    }
    setRowsPerPage(perPage);
    setRowsPerPageOptions(rowsPerPage);
    setView(view);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleSearchChange = (e:React.ChangeEvent<HTMLInputElement>) => {
    const inputValue = e.target.value
    setSearchTerm(inputValue)
    

    if(inputValue === ""){
      setFilteredRows(rows)
    }
    
  }

  const handleFilterData = () => {
    const filterData = filteredRows.filter((item:any) => 
      item?.nodeIdentifier.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item?.serialNumber.includes(searchTerm)
    )
    setFilteredRows(filterData)
  }
  

  return (
    <Box sx={{ width: "100%" }} color="secondary">
      <NodeListTable sx={{ width: "100%", mb: 2 }} color="secondary">
     
        <NodeStatusListToolbar action={changeView}  handleSearchChange={handleSearchChange} searchTerm={searchTerm} handleFilterData={handleFilterData}/>
        {view === Views.list && (
          <ListView rows={filteredRows} page={page} rowsPerPage={rowsPerPage}/>
        )}
        {view === Views.card && (
          <CardView rows={rows} page={page} rowsPerPage={rowsPerPage} />
        )}
        <TablePagination
          rowsPerPageOptions={rowsPerPageOptions}
          component="div"
          count={rows.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </NodeListTable>
    </Box>
  );
}

export default NodeStatusView;
