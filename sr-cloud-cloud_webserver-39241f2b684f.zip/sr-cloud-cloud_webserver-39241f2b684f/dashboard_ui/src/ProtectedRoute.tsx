import React from 'react';
import { Navigate } from 'react-router-dom';


interface ProtectedRouteProps{
  element: JSX.Element;
}

function ProtectedRoute({ element, ...rest }: ProtectedRouteProps){
  const isAuthenticated = sessionStorage.getItem('token');
  return isAuthenticated && isAuthenticated!== ''  ? (
    element
  ) : (
    <Navigate to="/login" />
  );
};

export default ProtectedRoute;