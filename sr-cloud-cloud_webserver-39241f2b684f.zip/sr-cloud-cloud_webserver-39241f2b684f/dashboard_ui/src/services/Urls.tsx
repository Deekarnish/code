import { baseUrl } from "../config";

const Urls = {
    BaseUrl: baseUrl,
    getUserToken: '/api/v1.0/user/getToken',
    refreshUserToken: '/api/v1.0/user/refreshToken',
    node: '/node',
    dutLibrary: '/DutLibrary',
    dut: '/Dut',
    template: '/Template',
    firmwareUpdate: '/firmware-update',
    requestPool: '/tests/request',
    requestPoolCount: '/tests/count',
    dutChange: '/initiate-dut-change',
    applyTemplate: '/apply-template',
    verifyTemplate: '/verify-template',
    dashboardGraph: '/Dashboard/graph', 
    dashboardRequest:'/Dashboard/requests',
    dashboardMeasurment:'/Dashboard/measurement',
    dashboardMeasurmentReport:'/Dashboard/measurement/report',
    dashboardCard:'/Dashboard/card',
    getUserDetails:'/api/v1.0/user',
    editUserDetails:'api/v1.0/user/userId:int',
};

export default Urls;
