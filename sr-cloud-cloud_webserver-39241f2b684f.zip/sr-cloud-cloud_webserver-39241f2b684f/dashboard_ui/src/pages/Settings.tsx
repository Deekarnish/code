import React from 'react'
import SettingManagement from '../components/settings/SettingManagement'

export default function Settings() {
  let roleId = localStorage.getItem('roleId')
  return (
    <>
      <div 
      style={roleId === "2" ? { display: "none" } : {}}
      >
        <SettingManagement />
      </div>
    </>
  )
}
