import React from "react";
import DUTMasterList from "../feature/dutMasterLibrary/DUTMasterList";

function DUTMasterLibrary() {
  return (
    <div>
      <DUTMasterList />
    </div>
  );
}

export default DUTMasterLibrary;
