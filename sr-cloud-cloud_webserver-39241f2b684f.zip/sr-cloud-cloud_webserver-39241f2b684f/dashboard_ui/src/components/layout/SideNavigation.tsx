import React, { useEffect, useState } from "react";
import { styled } from "@mui/material/styles";
import Divider from "@mui/material/Divider";
import Paper from "@mui/material/Paper";
import MenuList from "@mui/material/MenuList";
import MenuItem from "@mui/material/MenuItem";
import ListItemText from "@mui/material/ListItemText";
import ListItemIcon from "@mui/material/ListItemIcon";
import Overview from "../../assets/icons/Overview";
import NodeStatus from "../../assets/icons/NodeStatus";
import RequestPool from "../../assets/icons/RequestPool";
import NodeSetup from "../../assets/icons/NodeSetup";
import Settings from "../../assets/icons/Settings";
import Help from "../../assets/icons/Help";
import robot from "../../assets/images/robots.png";
import { Menu } from "../../types";
import { useLocation, useNavigate } from "react-router-dom";
import { Avatar, Grid, Typography } from "@mui/material";
import MenuIcon from '@mui/icons-material/Menu';

const menuList: Menu[] = [
  { id: 0, name: "Overview", link: "" },
  { id: 1, name: "Node Status", link: "nodestatus" },
  { id: 2, name: "Request Pool", link: "requestpool" },
  { id: 3, name: "Node Setup", link: "nodesetup" },
  { id: 4, name: "Settings", link: "settings" },
  { id: 5, name: "Help", link: "" },
];


const MenuContainer = styled(Paper)`
  width: 255px;
  max-width: 100%;
  border-radius: 0;
  min-height: 100vh;
  height: 100%;
  padding-top: 34px;


  @media (max-width: 1000px) {
    width: 280px !important; 
    z-index: 99 !important;
    max-width:400px;
    position:relative;   
  }
`;

const MenuContent = styled(Paper)`
  width: 100px;
  max-width: 100%;
  border-radius: 0;
  min-height: 100vh;
  height: 100%;
  padding-top: 34px;
`

const NavItem = styled(MenuItem)(
  ({ theme }) => `
  padding-left: 25px;
  padding-top: 10px;

  &.Mui-selected, &.Mui-selected:hover {
    padding-left: 22px;
    background-color: ${theme.palette.grey[100]};
    border-left: 3px solid ${theme.palette.grey[800]};
  }
`
);

const NavListText = styled(ListItemText)(
  ({ theme }) => `
    color: ${theme.palette.grey[700]};
    text-align: left;

    &.selected {
        color: ${theme.palette.grey[800]};
    }
  `
);

const ItemDivider = styled(Divider)`
  margin-top: 16px !important;
  margin-bottom: 16px !important;
  opacity: 0.06;
`;

const Heading = styled(Typography)(
  ({ theme }) => `
      color: ${theme.palette.grey[700]};
      text-align: left;
      opacity: 0.7;
      margin-bottom: 30px;
      margin-left: 16px;
    `
);

const GridContainer = styled(Grid)`
  padding-left: 25px;
`;

const LogoImage = styled(Avatar)`
  background-color: #3751ff;
`;

const HamburgerIcon = styled(MenuIcon)`
  font-size: 34px;
  margin-left: 15px;
  cursor: pointer;
  padding:15px;

  @media (min-width: 1001px) {
    display: none; 
  }
`;



function SideNavigation() {
  const navigate = useNavigate();
  const [selectedIndex, setSelectedIndex] = React.useState(-1);
  const [open, setOpen] = useState(false)
  const [windowWidth, setWindowWidth] = useState(window.innerWidth);

  const handleResize = () => {
    setWindowWidth(window.innerWidth);
    if (window.innerWidth > 1100) {
      setOpen(false);
    }
  };

  const roleId = localStorage.getItem("roleId")

  useEffect(() => {
    window.addEventListener('resize', handleResize);
    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, [windowWidth]);

  const onHandleMenuClick = () => {
    setOpen(open => !open)
  }


  const icon = (index: number, color: string, opacity: string) => {
    let menuIcon: JSX.Element = <> </>;
    switch (index) {
      case 0:
        menuIcon = (
          <Overview
            sx={{ color: color, paddingTop: "10px" }}
            opacity={opacity}
          />
        );
        break;
      case 1:
        menuIcon = (
          <NodeStatus
            sx={{ color: color, paddingTop: "10px" }}
            opacity={opacity}
          />
        );
        break;
      case 2:
        menuIcon = (
          <RequestPool
            sx={{ color: color, paddingTop: "10px" }}
            opacity={opacity}
          />
        );
        break;
      case 3:
        menuIcon = (
          <NodeSetup
            sx={{ color: color, paddingTop: "10px" }}
            opacity={opacity}
          />
        );
        break;
      case 4:
        menuIcon = (
          <Settings
            sx={{ color: color, paddingTop: "10px" }}
            opacity={opacity}
          />
        );
        break;
      case 5:
        menuIcon = (
          <Help sx={{ color: color, paddingTop: "10px" }} opacity={opacity} />
        );
        break;
      default:
        break;
    }

    return menuIcon;
  };

  const handleMenuItemClick = (
    event: React.MouseEvent<HTMLLIElement, MouseEvent>,
    menuItem: Menu
  ) => {
    setSelectedIndex(menuItem.id);
    setOpen(false)
    if (roleId === "3" && (menuItem.name === "Node Status" || menuItem.name === "Request Pool")) {
      return
    } else {
      navigate(`/${menuItem.link}`, { state: { title: menuItem.name } });
    }

  };

  const location = useLocation();

  useEffect(() => {
    let index = menuList.findIndex(
      (menu: Menu) => location.pathname.split('/')[1] === menu.link
    );
    setSelectedIndex(index);
  }, [location]);



  return (
    <>
    {
      roleId === "2" ? <></> :(
        
          windowWidth <= 1000 ? (
            open ? (
              <MenuContainer>
                <HamburgerIcon onClick={onHandleMenuClick} />
                <GridContainer container direction="row">
                  <Grid item xs={2}>
                    <LogoImage src={robot} alt="logo" />
                  </Grid>
                  <Grid item xs={10}>
                    <Heading variant="h2">Robot Automation Framework</Heading>
                  </Grid>
                </GridContainer>
                {/* <MenuList>
  
                  {menuList.map((menuItem: Menu, index: number) => [
                    <NavItem
                      selected={selectedIndex === index}
                      onClick={(event: React.MouseEvent<HTMLLIElement, MouseEvent>) =>
                        handleMenuItemClick(event, menuItem)
                      }
                    >
                      <ListItemIcon>
                        {icon(
                          index,
                          selectedIndex === index ? "grey.800" : "grey.900",
                          selectedIndex === index ? "1" : "0.4"
                        )}
                      </ListItemIcon>
                      <NavListText
                        className={`${selectedIndex === index ? "selected" : ""}`}
                      >
                        {menuItem.name}
                      </NavListText>
                    </NavItem>,
                    index === 3 && <ItemDivider />,
                  ])}
                </MenuList> */}
  
                <MenuList>
                  {menuList.map((menuItem: Menu, index: number) => {
  
                    if (roleId === "3" && menuItem.name === "Request Pool") {
                      return null;
                    } else {
                      return [
                        <NavItem
                          key={index}
                          selected={selectedIndex === index}
                          onClick={(event: React.MouseEvent<HTMLLIElement, MouseEvent>) =>
                            handleMenuItemClick(event, menuItem)
                          }
                        >
                          <ListItemIcon>
                            {icon(
                              index,
                              selectedIndex === index ? "grey.800" : "grey.900",
                              selectedIndex === index ? "1" : "0.4"
                            )}
                          </ListItemIcon>
                          <NavListText
                            className={`${selectedIndex === index ? "selected" : ""}`}
                          >
                            {menuItem.name}
                          </NavListText>
                        </NavItem>,
                        index === 3 && <ItemDivider key={"divider" + index} />,
                      ];
                    }
                  })}
                </MenuList>
              </MenuContainer>
            ) :
              <MenuContent>
                <HamburgerIcon onClick={onHandleMenuClick} />
              </MenuContent>
          )
            :
            <MenuContainer>
              <HamburgerIcon onClick={onHandleMenuClick} />
              <GridContainer container direction="row">
                <Grid item xs={2}>
                  <LogoImage src={robot} alt="logo" />
                </Grid>
                <Grid item xs={10}>
                  <Heading variant="h2">Robot Automation Framework</Heading>
                </Grid>
              </GridContainer>
              <MenuList>
                {menuList.map((menuItem: Menu, index: number) => {
  
                  if (roleId === "3" && menuItem.name === "Request Pool") {
                    return null;
                  } else {
                    return [
                      <NavItem
                        key={index}
                        selected={selectedIndex === index}
                        onClick={(event: React.MouseEvent<HTMLLIElement, MouseEvent>) =>
                          handleMenuItemClick(event, menuItem)
                        }
                      >
                        <ListItemIcon>
                          {icon(
                            index,
                            selectedIndex === index ? "grey.800" : "grey.900",
                            selectedIndex === index ? "1" : "0.4"
                          )}
                        </ListItemIcon>
                        <NavListText
                          className={`${selectedIndex === index ? "selected" : ""}`}
                        >
                          {menuItem.name}
                        </NavListText>
                      </NavItem>,
                      index === 3 && <ItemDivider key={"divider" + index} />,
                    ];
                  }
                })}
              </MenuList>
            </MenuContainer>
        
      )
    }
      
    </>
  );
}

export default SideNavigation;
